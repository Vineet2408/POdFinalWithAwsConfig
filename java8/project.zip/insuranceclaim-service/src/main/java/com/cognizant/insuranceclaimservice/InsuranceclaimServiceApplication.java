package com.cognizant.insuranceclaimservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;





@SpringBootApplication

public class InsuranceclaimServiceApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(InsuranceclaimServiceApplication.class, args);
	}

}
