insert into USER_DATA values ('admin','','pwd123','101');
insert into USER_DATA values ('deeptha','','pwd123','102');
insert into USER_DATA values ('utsav','','pwd123','103');
insert into USER_DATA values ('jahanvi','','pwd123','104');
insert into USER_DATA values ('vineet','','pwd123','105');
