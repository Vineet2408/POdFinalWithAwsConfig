package com.cts.iptms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpTreatmentOfferingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpTreatmentOfferingsApplication.class, args);
	}

}
